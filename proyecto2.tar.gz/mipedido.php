<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="css\brewery1.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brewery</title>
</head>

<body>
<h1 align="center">Brewery</h1>
<span id="liveclock" style="position:absolute;right:0;top:0;"></span><script language="JavaScript" type="text/javascript">
 <!--

function show5(){
if (!document.layers&&!document.all&&!document.getElementById)
return

 var Digital=new Date()
 var hours=Digital.getHours()
 var minutes=Digital.getMinutes()
 var seconds=Digital.getSeconds()

var dn="PM"
if (hours<12)
dn="AM"
if (hours>12)
hours=hours-12
if (hours==0)
hours=12

 if (minutes<=9)
 minutes="0"+minutes
 if (seconds<=9)
 seconds="0"+seconds
//change font size here to your desire
myclock="<font size='5' face='Arial' ><b><font size='1'></font></br>"+hours+":"+minutes+":"
 +seconds+" "+dn+"</b></font>"
if (document.layers){
document.layers.liveclock.document.write(myclock)
document.layers.liveclock.document.close()
}
else if (document.all)
liveclock.innerHTML=myclock
else if (document.getElementById)
document.getElementById("liveclock").innerHTML=myclock
setTimeout("show5()",1000)
 }


window.onload=show5
 //-->
 </script>
<div class="topnav" id="myTopnav">
  <a href="index.html">Inicio</a>
  <a href="historia.html">Historia</a>
      <div class="dropdown">
          <button class="dropbtn">Cervezas</button>
              <div class="dropdown-content">
                <a href="rubia.php">Rubia</a>
                <a href="tostada.php">Tostada</a>
                <a href="negra.php">Negra</a>
              </div>
   	 </div>
  <a href="contacto.html">Contacto</a>
  <a href="mipedido.php">Mi Pedido</a>
  <a href="pedidos.php">Pedidos</a>
</div>
<br />
<br />
<h2>Realiza Tu Pedido</h2>
<br />


<?php
if ( !isset($_POST['codped']) ) {
?>
        
    <form action="<?php $_SERVER['PHP_SELF'] ?>"  method="post">
        Nº Pedido: <input type="text" name="codped" size="9" /><br/>
        Nombre y Apellido: <input type="text" name="nomped" size="40" /><br/>
        Cantidad Rubias: <input type="text" name="cantrub" size="5" /><br/>
	Cantidad Tostadas: <input type="text" name="canttos" size="5" /><br/>
	Cantidad Negras: <input type="text" name="cantneg" size="5" /><br/>
        <input type="submit" name="env" value="ENVIAR"/>
    </form>	  
    
<?php    
}
else {
    $username = BORJA;
    $password = abc1234;
    $servername = localhost;
    $database = brewery;
    $table = pedidos; 
try {
    //Conexión con una base de datos del servidor
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Conexión con la base de datos '".$database."' del servidor '".$servername."' realizada.<br/>";
    
    echo "Nº Pedido: ".$_POST['codped']."<br/>";
    echo "Nombre y Apellido: ".$_POST['nomped']."<br/>";
    echo "Cantidad Rubias : ".$_POST['cantrub']."<br/>";  
    echo "Cantidad Tostadas : ".$_POST['canttos']."<br/>";
    echo "Cantidad Negras : ".$_POST['cantneg']."<br/>";  
    
    $sql = "INSERT INTO ".$table." VALUES (".$_POST['codped'].",'".$_POST['nomped']."','".$_POST['cantrub']."','".$_POST['canttos']."','".$_POST['cantneg']."')";
     $stmt = $conn->prepare($sql);
   $stmt->execute();
    echo "Pedido Realizado con &Eacute;xito.<br/>";
    }
catch(PDOException $e) {
    if ($e->getCode() == "23000")
        echo "Imposible insertar el registro porque esa clave de pedido ya existe."."<br/>";
    else
        echo $e->getMessage();
}
}    
 //print "<br/><br/><br/>sql: ".$sql;
?>
</body>
</html>
